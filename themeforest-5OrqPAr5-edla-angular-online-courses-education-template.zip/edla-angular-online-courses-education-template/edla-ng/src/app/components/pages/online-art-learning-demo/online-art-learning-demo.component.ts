import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-online-art-learning-demo',
  templateUrl: './online-art-learning-demo.component.html',
  styleUrls: ['./online-art-learning-demo.component.scss']
})
export class OnlineArtLearningDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
