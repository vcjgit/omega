import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-esd-banner',
  templateUrl: './esd-banner.component.html',
  styleUrls: ['./esd-banner.component.scss']
})
export class EsdBannerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
