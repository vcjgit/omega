import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-elearning-school-demo',
  templateUrl: './elearning-school-demo.component.html',
  styleUrls: ['./elearning-school-demo.component.scss']
})
export class ElearningSchoolDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
