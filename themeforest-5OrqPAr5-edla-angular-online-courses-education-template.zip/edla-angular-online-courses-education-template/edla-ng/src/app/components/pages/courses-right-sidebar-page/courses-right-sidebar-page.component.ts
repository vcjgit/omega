import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses-right-sidebar-page',
  templateUrl: './courses-right-sidebar-page.component.html',
  styleUrls: ['./courses-right-sidebar-page.component.scss']
})
export class CoursesRightSidebarPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
