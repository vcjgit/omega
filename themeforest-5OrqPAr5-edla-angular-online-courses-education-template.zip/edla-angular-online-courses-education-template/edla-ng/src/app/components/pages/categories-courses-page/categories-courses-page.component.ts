import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categories-courses-page',
  templateUrl: './categories-courses-page.component.html',
  styleUrls: ['./categories-courses-page.component.scss']
})
export class CategoriesCoursesPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
