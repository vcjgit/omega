import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-development-courses',
  templateUrl: './development-courses.component.html',
  styleUrls: ['./development-courses.component.scss']
})
export class DevelopmentCoursesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
