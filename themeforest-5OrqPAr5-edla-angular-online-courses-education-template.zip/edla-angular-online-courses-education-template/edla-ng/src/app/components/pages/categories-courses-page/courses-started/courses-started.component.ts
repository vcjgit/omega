import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses-started',
  templateUrl: './courses-started.component.html',
  styleUrls: ['./courses-started.component.scss']
})
export class CoursesStartedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
