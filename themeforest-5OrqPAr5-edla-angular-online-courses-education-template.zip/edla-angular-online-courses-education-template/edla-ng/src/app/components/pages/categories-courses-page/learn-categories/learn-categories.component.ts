import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learn-categories',
  templateUrl: './learn-categories.component.html',
  styleUrls: ['./learn-categories.component.scss']
})
export class LearnCategoriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
