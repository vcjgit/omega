import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-online-education-courses-demo',
  templateUrl: './online-education-courses-demo.component.html',
  styleUrls: ['./online-education-courses-demo.component.scss']
})
export class OnlineEducationCoursesDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
