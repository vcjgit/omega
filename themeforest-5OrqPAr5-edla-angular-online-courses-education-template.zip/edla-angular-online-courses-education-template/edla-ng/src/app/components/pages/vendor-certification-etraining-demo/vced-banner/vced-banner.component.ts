import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vced-banner',
  templateUrl: './vced-banner.component.html',
  styleUrls: ['./vced-banner.component.scss']
})
export class VcedBannerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
