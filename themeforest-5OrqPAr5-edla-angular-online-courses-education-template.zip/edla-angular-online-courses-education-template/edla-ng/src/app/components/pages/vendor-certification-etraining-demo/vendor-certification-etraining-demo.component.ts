import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-certification-etraining-demo',
  templateUrl: './vendor-certification-etraining-demo.component.html',
  styleUrls: ['./vendor-certification-etraining-demo.component.scss']
})
export class VendorCertificationEtrainingDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
