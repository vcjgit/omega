import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-membership-levels-page',
  templateUrl: './membership-levels-page.component.html',
  styleUrls: ['./membership-levels-page.component.scss']
})
export class MembershipLevelsPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
