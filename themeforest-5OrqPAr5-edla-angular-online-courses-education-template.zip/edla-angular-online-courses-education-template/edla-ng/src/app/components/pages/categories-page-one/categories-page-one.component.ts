import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categories-page-one',
  templateUrl: './categories-page-one.component.html',
  styleUrls: ['./categories-page-one.component.scss']
})
export class CategoriesPageOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
