import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sticky-sidebar-courses-single-page',
  templateUrl: './sticky-sidebar-courses-single-page.component.html',
  styleUrls: ['./sticky-sidebar-courses-single-page.component.scss']
})
export class StickySidebarCoursesSinglePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
