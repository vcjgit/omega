import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-online-training-school-demo',
  templateUrl: './online-training-school-demo.component.html',
  styleUrls: ['./online-training-school-demo.component.scss']
})
export class OnlineTrainingSchoolDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
