import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otsd-banner',
  templateUrl: './otsd-banner.component.html',
  styleUrls: ['./otsd-banner.component.scss']
})
export class OtsdBannerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
