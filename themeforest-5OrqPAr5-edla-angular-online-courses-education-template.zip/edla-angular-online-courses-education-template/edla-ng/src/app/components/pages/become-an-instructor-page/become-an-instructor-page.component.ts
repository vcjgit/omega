import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-become-an-instructor-page',
  templateUrl: './become-an-instructor-page.component.html',
  styleUrls: ['./become-an-instructor-page.component.scss']
})
export class BecomeAnInstructorPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
