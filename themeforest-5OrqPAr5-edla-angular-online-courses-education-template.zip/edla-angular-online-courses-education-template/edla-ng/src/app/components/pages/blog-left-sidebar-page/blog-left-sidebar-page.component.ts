import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-left-sidebar-page',
  templateUrl: './blog-left-sidebar-page.component.html',
  styleUrls: ['./blog-left-sidebar-page.component.scss']
})
export class BlogLeftSidebarPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
