import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses-left-sidebar-page',
  templateUrl: './courses-left-sidebar-page.component.html',
  styleUrls: ['./courses-left-sidebar-page.component.scss']
})
export class CoursesLeftSidebarPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
