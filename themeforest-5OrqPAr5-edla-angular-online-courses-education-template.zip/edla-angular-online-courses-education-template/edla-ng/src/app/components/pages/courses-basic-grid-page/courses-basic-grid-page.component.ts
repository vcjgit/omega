import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses-basic-grid-page',
  templateUrl: './courses-basic-grid-page.component.html',
  styleUrls: ['./courses-basic-grid-page.component.scss']
})
export class CoursesBasicGridPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
