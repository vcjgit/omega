import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-guide-page',
  templateUrl: './purchase-guide-page.component.html',
  styleUrls: ['./purchase-guide-page.component.scss']
})
export class PurchaseGuidePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
