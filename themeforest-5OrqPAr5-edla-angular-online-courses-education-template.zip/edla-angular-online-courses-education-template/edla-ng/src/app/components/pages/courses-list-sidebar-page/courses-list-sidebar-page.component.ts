import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses-list-sidebar-page',
  templateUrl: './courses-list-sidebar-page.component.html',
  styleUrls: ['./courses-list-sidebar-page.component.scss']
})
export class CoursesListSidebarPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
