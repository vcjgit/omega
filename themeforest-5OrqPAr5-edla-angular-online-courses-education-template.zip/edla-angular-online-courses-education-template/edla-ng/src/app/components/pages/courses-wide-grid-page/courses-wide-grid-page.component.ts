import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses-wide-grid-page',
  templateUrl: './courses-wide-grid-page.component.html',
  styleUrls: ['./courses-wide-grid-page.component.scss']
})
export class CoursesWideGridPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
