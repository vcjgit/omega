import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-page-one',
  templateUrl: './contact-page-one.component.html',
  styleUrls: ['./contact-page-one.component.scss']
})
export class ContactPageOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
