import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-articles',
  templateUrl: './business-articles.component.html',
  styleUrls: ['./business-articles.component.scss']
})
export class BusinessArticlesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
