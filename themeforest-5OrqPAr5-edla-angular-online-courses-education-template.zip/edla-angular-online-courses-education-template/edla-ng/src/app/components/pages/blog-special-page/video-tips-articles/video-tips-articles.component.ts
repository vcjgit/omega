import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-video-tips-articles',
  templateUrl: './video-tips-articles.component.html',
  styleUrls: ['./video-tips-articles.component.scss']
})
export class VideoTipsArticlesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
