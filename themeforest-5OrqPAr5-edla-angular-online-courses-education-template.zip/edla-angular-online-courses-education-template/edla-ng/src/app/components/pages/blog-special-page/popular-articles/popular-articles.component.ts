import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popular-articles',
  templateUrl: './popular-articles.component.html',
  styleUrls: ['./popular-articles.component.scss']
})
export class PopularArticlesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
