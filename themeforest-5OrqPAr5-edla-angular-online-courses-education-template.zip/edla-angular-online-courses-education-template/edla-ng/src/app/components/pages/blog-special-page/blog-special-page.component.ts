import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-special-page',
  templateUrl: './blog-special-page.component.html',
  styleUrls: ['./blog-special-page.component.scss']
})
export class BlogSpecialPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
