import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-success-stories-page',
  templateUrl: './success-stories-page.component.html',
  styleUrls: ['./success-stories-page.component.scss']
})
export class SuccessStoriesPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
