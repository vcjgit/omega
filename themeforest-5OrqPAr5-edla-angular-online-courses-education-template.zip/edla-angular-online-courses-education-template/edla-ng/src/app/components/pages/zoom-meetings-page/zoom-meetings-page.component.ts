import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zoom-meetings-page',
  templateUrl: './zoom-meetings-page.component.html',
  styleUrls: ['./zoom-meetings-page.component.scss']
})
export class ZoomMeetingsPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
