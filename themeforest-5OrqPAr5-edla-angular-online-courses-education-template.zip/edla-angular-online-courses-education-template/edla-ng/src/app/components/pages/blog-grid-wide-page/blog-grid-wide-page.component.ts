import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-grid-wide-page',
  templateUrl: './blog-grid-wide-page.component.html',
  styleUrls: ['./blog-grid-wide-page.component.scss']
})
export class BlogGridWidePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
