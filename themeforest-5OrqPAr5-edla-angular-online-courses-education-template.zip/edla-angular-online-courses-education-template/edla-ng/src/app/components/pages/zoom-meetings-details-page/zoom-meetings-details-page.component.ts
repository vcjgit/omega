import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zoom-meetings-details-page',
  templateUrl: './zoom-meetings-details-page.component.html',
  styleUrls: ['./zoom-meetings-details-page.component.scss']
})
export class ZoomMeetingsDetailsPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
