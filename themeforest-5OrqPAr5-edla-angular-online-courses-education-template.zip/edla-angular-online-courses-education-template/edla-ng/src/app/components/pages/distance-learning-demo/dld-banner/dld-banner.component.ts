import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dld-banner',
  templateUrl: './dld-banner.component.html',
  styleUrls: ['./dld-banner.component.scss']
})
export class DldBannerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
