import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-distance-learning-demo',
  templateUrl: './distance-learning-demo.component.html',
  styleUrls: ['./distance-learning-demo.component.scss']
})
export class DistanceLearningDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
