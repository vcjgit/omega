import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instructors-profile-page',
  templateUrl: './instructors-profile-page.component.html',
  styleUrls: ['./instructors-profile-page.component.scss']
})
export class InstructorsProfilePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
