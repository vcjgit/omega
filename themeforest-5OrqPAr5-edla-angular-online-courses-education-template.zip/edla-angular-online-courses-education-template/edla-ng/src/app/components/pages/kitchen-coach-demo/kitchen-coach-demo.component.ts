import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kitchen-coach-demo',
  templateUrl: './kitchen-coach-demo.component.html',
  styleUrls: ['./kitchen-coach-demo.component.scss']
})
export class KitchenCoachDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
