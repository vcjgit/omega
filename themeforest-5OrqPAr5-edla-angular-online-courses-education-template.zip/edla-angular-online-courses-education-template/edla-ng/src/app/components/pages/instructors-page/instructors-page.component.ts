import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instructors-page',
  templateUrl: './instructors-page.component.html',
  styleUrls: ['./instructors-page.component.scss']
})
export class InstructorsPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
