import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses-modern-grid-page',
  templateUrl: './courses-modern-grid-page.component.html',
  styleUrls: ['./courses-modern-grid-page.component.scss']
})
export class CoursesModernGridPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
