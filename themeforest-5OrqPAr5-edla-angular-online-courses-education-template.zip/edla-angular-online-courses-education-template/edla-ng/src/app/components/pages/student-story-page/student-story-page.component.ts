import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-story-page',
  templateUrl: './student-story-page.component.html',
  styleUrls: ['./student-story-page.component.scss']
})
export class StudentStoryPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
