import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-grid-page',
  templateUrl: './blog-grid-page.component.html',
  styleUrls: ['./blog-grid-page.component.scss']
})
export class BlogGridPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
