import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-page-two',
  templateUrl: './contact-page-two.component.html',
  styleUrls: ['./contact-page-two.component.scss']
})
export class ContactPageTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
