import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categories-page-two',
  templateUrl: './categories-page-two.component.html',
  styleUrls: ['./categories-page-two.component.scss']
})
export class CategoriesPageTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
