import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learning-management-demo',
  templateUrl: './learning-management-demo.component.html',
  styleUrls: ['./learning-management-demo.component.scss']
})
export class LearningManagementDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
