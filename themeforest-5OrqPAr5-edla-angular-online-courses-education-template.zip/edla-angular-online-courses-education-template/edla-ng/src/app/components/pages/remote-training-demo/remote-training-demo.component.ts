import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remote-training-demo',
  templateUrl: './remote-training-demo.component.html',
  styleUrls: ['./remote-training-demo.component.scss']
})
export class RemoteTrainingDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
