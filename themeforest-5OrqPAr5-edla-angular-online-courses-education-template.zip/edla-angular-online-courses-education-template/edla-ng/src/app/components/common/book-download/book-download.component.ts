import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-book-download',
    templateUrl: './book-download.component.html',
    styleUrls: ['./book-download.component.scss']
})
export class BookDownloadComponent implements OnInit {

    constructor() { }

    ngOnInit(): void {}

}