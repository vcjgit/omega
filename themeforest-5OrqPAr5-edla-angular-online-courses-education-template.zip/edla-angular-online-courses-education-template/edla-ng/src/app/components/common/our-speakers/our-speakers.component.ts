import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-speakers',
  templateUrl: './our-speakers.component.html',
  styleUrls: ['./our-speakers.component.scss']
})
export class OurSpeakersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
