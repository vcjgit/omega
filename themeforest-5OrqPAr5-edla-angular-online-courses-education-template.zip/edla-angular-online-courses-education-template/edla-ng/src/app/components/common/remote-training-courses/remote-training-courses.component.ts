import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remote-training-courses',
  templateUrl: './remote-training-courses.component.html',
  styleUrls: ['./remote-training-courses.component.scss']
})
export class RemoteTrainingCoursesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
