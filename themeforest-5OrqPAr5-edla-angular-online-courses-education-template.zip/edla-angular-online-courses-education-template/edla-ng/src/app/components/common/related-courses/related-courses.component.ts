import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-related-courses',
  templateUrl: './related-courses.component.html',
  styleUrls: ['./related-courses.component.scss']
})
export class RelatedCoursesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
