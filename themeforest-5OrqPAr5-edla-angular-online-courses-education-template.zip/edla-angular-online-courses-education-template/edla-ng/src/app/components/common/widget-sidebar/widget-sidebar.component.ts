import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-widget-sidebar',
  templateUrl: './widget-sidebar.component.html',
  styleUrls: ['./widget-sidebar.component.scss']
})
export class WidgetSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
