import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses-sidebar',
  templateUrl: './courses-sidebar.component.html',
  styleUrls: ['./courses-sidebar.component.scss']
})
export class CoursesSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
