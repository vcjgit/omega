import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-management-courses',
  templateUrl: './project-management-courses.component.html',
  styleUrls: ['./project-management-courses.component.scss']
})
export class ProjectManagementCoursesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
