import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-trusted-companies',
    templateUrl: './trusted-companies.component.html',
    styleUrls: ['./trusted-companies.component.scss']
})
export class TrustedCompaniesComponent implements OnInit {

    constructor(
		public router: Router
    ) { }

    ngOnInit(): void {}

    trustedCompaniesContent = [
        {
            title: `Trusted by companies`,
            paragraph: `Explore all of our courses and pick your suitable ones to enroll and start learning with us!`,
            buttonText: `View All Partners`,
            buttonLink: `/`,
            partnerList: [
                {
                    img: `assets/img/partner/partner1.png`,
                },
                {
                    img: `assets/img/partner/partner2.png`,
                },
                {
                    img: `assets/img/partner/partner3.png`,
                },
                {
                    img: `assets/img/partner/partner4.png`,
                },
                {
                    img: `assets/img/partner/partner5.png`,
                },
                {
                    img: `assets/img/partner/partner6.png`,
                },
                {
                    img: `assets/img/partner/partner7.png`,
                },
                {
                    img: `assets/img/partner/partner8.png`,
                },
                {
                    img: `assets/img/partner/partner9.png`,
                },
                {
                    img: `assets/img/partner/partner10.png`,
                },
                {
                    img: `assets/img/partner/partner11.png`,
                },
                {
                    img: `assets/img/partner/partner12.png`,
                }
            ]
        }
    ]

}