import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kitchen-coach-courses',
  templateUrl: './kitchen-coach-courses.component.html',
  styleUrls: ['./kitchen-coach-courses.component.scss']
})
export class KitchenCoachCoursesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
